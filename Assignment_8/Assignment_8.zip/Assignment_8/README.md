##Assignment 8 AI - CSCI 3102

##Run
```
python WallingAssignment8.py
```
